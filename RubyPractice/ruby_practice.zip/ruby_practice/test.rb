require 'fileutils'


'''
def destroyLxcContainers  
  `sudo lxc-ls --fancy --stopped`.split("\n").select {|x| not x.match? /^NAME/}.map { |x| x.split.first }.each do |vm|
    begin
	  #raise	
      `sudo lxc-destroy #{vm}`
    rescue Exception
      print "Failed destroying VM : #{vm}" 
    end
  end
end




def destroyLxcContainers  
  `sudo lxc-ls --fancy --stopped`.split("\n").select {|x| not x.match? /^NAME/}.map { |x| x.split.first }.each do |vm|
    begin
      if system("sudo lxc-destroy #{vm}")
        print "Destroyed the VM: #{vm}\n"
    rescue Exception
      print "Failed destroying VM : #{vm}" 
    end
  end
end



def destroyLxcContainers 
  #containerArray = system("sudo lxc-ls --fancy --stopped").split("\n").select {|x| not x.match? /^NAME/}.map { |x| x.split.first }
  containerArray = %x(/usr/bin/bash -c "sudo lxc-ls --fancy --stopped").split("\n").select {|x| not x.match? /^NAME/}.map { |x| x.split.first }
  if containerArray.size != 0
    containerArray.each do |vm|
      if system("sudo lxc-destroy #{vm}")
        print "Destroyed the VM: #{vm}\n"
      else
        print "Failed destroying VM : #{vm}" 
      end
    end
  else
    print "No Stopped Containers"
  end
end

'''

def destroyLxcContainers 
  #containerArray = system("sudo lxc-ls --fancy --stopped").split("\n").select {|x| not x.match? /^NAME/}.map { |x| x.split.first }
  container = %x(/usr/bin/bash -c "sudo lxc-ls --fancy --stopped").split("\n").select {|x| not x.match? /^NAME/}.map { |x| x.split.first }
  #if containerArray.size != 0
  #container = exec("sudo lxc-ls --fancy --stopped").split("\n").select {|x| not x.match? /^NAME/}.map { |x| x.split.first }
  container.each do |vm|
	if system("sudo lxc-destroy #{vm}")
	  print "Destroyed the VM: #{vm}\n"
	else
	  print "Failed destroying VM : #{vm}" 
	end
  end.empty? and begin
    print "No Stopped Containers"
  end
end


def test_scriptOld
  #container_command = File.join("/usr/bin", 'lxc-ls')
  containerstring = `sudo lxc-ls -f --stopped`
  #print container_list
  if !containerstring.to_s.strip.empty?
    containersline = containerstring.split("\n")
	containerslist = containersline.select {|x| not x.match? /^NAME/}.map { |x| x.split.first }
	containerslist.each do |container|
      if system("sudo lxc-destroy #{container}")
	    print "Destroyed the container: #{container}\n"
	  else
	    print "Failed destroying container : #{container}" 
	  end
    end
  else
    print "No Stopped Containers\n"
  end
end


def test_script
  #container_command = File.join("/usr/bin", 'lxc-ls')
  output = `sudo lxc-ls -f --stopped`
  #require 'pry'
  #binding.pry
  #print container_list
  numberofcleanedcontainers = 0
  if !output.to_s.strip.empty?
    containers = output.split("\n").select {|x| not x.match? /^NAME/}.map { |x| x.split.first }
	containers.each do |container|
      if system("sudo lxc-destroy #{container} verbose: false")
	    #print "Destroyed the container: #{container}\n"
		numberofcleanedcontainers = numberofcleanedcontainers + 1
	  else
	    puts "Failed destroying container : #{container}"
	  end
    end
  else
    puts "No Stopped Containers"
  end
  puts "Number of Cleaned Containers: #{numberofcleanedcontainers}"
end









test_script
