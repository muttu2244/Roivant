require 'rake'
require 'rake/tasklib'

require 'fileutils'
require 'find'

require 'tasks/utils/git'

module Tasks
  module Package
    class MasterOnly < ::Rake::TaskLib
      include ::Rake::DSL if defined?(::Rake::DSL)

      extend Tasks::Utils::Git

      def initialize
        return if Rake::Task.task_defined? 'package:master_only'
        define_tasks
      end

      def self.enable_package_wip?
        value = ENV['DEVOPS_ENABLE_PACKAGE_WIP'].to_s
        (value != '') and (value != '0')
      end

      def self.is_wip?
        checked_out_branch != 'master'
      end

      def define_tasks
        namespace :package do
          task :master_only do
            if self.class.is_wip? and not self.class.enable_package_wip?
              puts 'Deployment related operations on branches other than master are not enabled'
              exit 1
            end
          end
        end
      end
    end
  end
end

unless Rake::Task.task_defined? 'package:master_only'
  Tasks::Package::MasterOnly.new
end

