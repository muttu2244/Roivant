file 'motd' do
  action :delete
end
